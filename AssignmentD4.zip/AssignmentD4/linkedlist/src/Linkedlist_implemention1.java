class Linkedlist_implemention1 {
    Node head;
    public class Node{
        String data;
        Node next;
        Node (String data){
            this.data=data;
            this.next=null;
        }
    }
    public void addLast(String data){
        Node newNode=new Node(data);
        if(head==null){
            head=newNode;
            return;
        }
        Node currNode=head;
        while(currNode.next!=null){
            currNode=currNode.next;
        }
        currNode.next=newNode;
    }
    public void printlist(){
        Node currNode=head;
        while (currNode!=null){
            System.out.print(currNode.data+"-->");
            currNode=currNode.next;
        }
        System.out.println("null");
    }
    public void removeFirst(){
        if(head==null){
            System.out.println("Empty list Nothing to delete");
            return;
        }
        head=head.next;
    }

    public static void main(String[] args) {
        Linkedlist_implemention1 list=new Linkedlist_implemention1();
        list.addLast("my");
        list.addLast("name");
        list.addLast("is");
        list.addLast("anjali");
        list.printlist();
        list.removeFirst();
        list.printlist();

    }

}
