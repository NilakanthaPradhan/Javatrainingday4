import java.util.HashSet;
public class Linkedlist_Nthnode7 {
    Node head;

    public class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public void addLast(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node currNode = head;
        while (currNode.next != null) {
            currNode = currNode.next;
        }
        currNode.next = newNode;
    }

    public void printlist() {
        Node currNode = head;
        while (currNode != null) {
            System.out.print(currNode.data + "-->");
            currNode = currNode.next;
        }
        System.out.println("null");
    }

    public Node nthnode(int n) {
        if (head == null) {
            return null;
        }
        Node first = head;
        Node second = head;
        for(int i=0;i<n;i++){
            if(first == null) return null;
            first=first.next;
        }
        while(first!=null){
            first=first.next;
            second=second.next;
        }
        return second;
    }

    public static void main(String[] args) {
        Linkedlist_Nthnode7 list=new Linkedlist_Nthnode7();
        list.addLast(1);
        list.addLast(5);
        list.addLast(6);
        list.addLast(1);
        list.printlist();
        int n=2;
        Node nthans=list.nthnode(n);
        if(nthans!=null){
            System.out.println(nthans.data);
        }


    }

}
