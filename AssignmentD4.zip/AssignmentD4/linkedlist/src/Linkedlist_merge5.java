class Linkedlist_merge5{
    static class ListNode{
        int data;
        ListNode next;
        public ListNode(int data){
            this.data = data;
            this.next = null;
        }
    }
    public ListNode head;
    public ListNode tail;

    public void insert(int data){
        ListNode newNode = new ListNode(data);
        if(head == null){
            head = newNode;
            tail = newNode;
        }
        else{
            tail.next = newNode;
            tail = newNode;
        }
    }
    public  ListNode mergeTwoLists(ListNode list1, ListNode list2)
    {
        ListNode result = new ListNode(-1);
        ListNode p = result;
        while (list1 != null && list2 != null) {
            if (list1.data <= list2.data) {
                p.next = list1;
                list1 = list1.next;
            }

            else {
                p.next = list2;
                list2 = list2.next;
            }
            p = p.next;
        }
        if (list1 == null) {
            p.next = list2;
        }

        else if (list2 == null) {
            p.next = list1;
        }
        return result.next;
    }
    static void display(ListNode node)
    {
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.next;
        }
    }

    public static void main(String[] args) {
        Linkedlist_merge5 list1 = new Linkedlist_merge5();
        list1.insert(1);
        list1.insert(2);
        list1.insert(3);
        list1.insert(9);

        Linkedlist_merge5 list2 = new Linkedlist_merge5();
        list2.insert(4);
        list2.insert(10);
        list2.insert(11);

        Linkedlist_merge5 mergeList = new Linkedlist_merge5();
        ListNode mergedhead = mergeList.mergeTwoLists(list1.head, list2.head);

        mergeList.display(mergedhead);




    }
}


