import java.util.HashSet;

public class LinkedList_removeduplicate6{
    Node head;
    public class Node{
        int data;
        Node next;
        Node (int data){
            this.data=data;
            this.next=null;
        }
    }
    public void addLast(int data){
        Node newNode=new Node(data);
        if(head==null){
            head=newNode;
            return;
        }
        Node currNode=head;
        while(currNode.next!=null){
            currNode=currNode.next;
        }
        currNode.next=newNode;
    }
    public void printlist(){
        Node currNode=head;
        while (currNode!=null){
            System.out.print(currNode.data+"-->");
            currNode=currNode.next;
        }
        System.out.println("null");
    }
    public void removeDuplicate(){
        HashSet<Integer> seen=new HashSet<>();
        Node current=head;
        Node previous=null;
        while(current!=null){
            if(seen.contains(current.data)){
                previous.next=current.next;
            }else {
                seen.add(current.data);
                previous=current;
            }
            current=current.next;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        LinkedList_removeduplicate6 list=new LinkedList_removeduplicate6();
        list.addLast(1);
        list.addLast(5);
        list.addLast(6);
        list.addLast(1);
        list.printlist();
       list.removeDuplicate();
        list.printlist();

    }

}
