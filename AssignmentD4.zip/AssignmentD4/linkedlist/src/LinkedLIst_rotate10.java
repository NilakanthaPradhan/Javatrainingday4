class ListNode {
    int val;
    ListNode next;

    ListNode(int val) {
        this.val = val;
        this.next = null;
    }
}

public class LinkedLIst_rotate10{

    public static ListNode rotate(ListNode head, int k) {
        if (head == null || head.next == null) {
            return head;
        }

        int cnt = 1;
        ListNode tail = head;

        while (tail.next != null) {
            cnt++;
            tail = tail.next;
        }

        tail.next = head; // Make it circular

        int count = cnt - (k % cnt); // Calculate the effective number of rotations
        ListNode temp = head;

        while (count > 1) {
            temp = temp.next;
            count--;
        }

        head = temp.next;
        temp.next = null;

        return head;
    }

    // Method to print the linked list
    public static void printList(ListNode head) {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.val + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        ListNode head = new ListNode(1);
        head.next = new ListNode(2);
        head.next.next = new ListNode(3);
        head.next.next.next = new ListNode(4);
        head.next.next.next.next = new ListNode(5);

        System.out.println("Original List: ");
        printList(head);

        int k = 2;
        head = rotate(head, k);

        System.out.println("Rotated List: ");
        printList(head);
    }
}



