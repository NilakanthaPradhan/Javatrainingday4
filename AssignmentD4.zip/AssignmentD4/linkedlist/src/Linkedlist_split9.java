public class Linkedlist_split9 {
    Node head;

    public class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public void addLast(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node currNode = head;
        while (currNode.next != null) {
            currNode = currNode.next;
        }
        currNode.next = newNode;
    }

    public void printlist(Node head) {
        Node currNode = head;
        while (currNode != null) {
            System.out.print(currNode.data + "-->");
            currNode = currNode.next;
        }
        System.out.println("null");
    }

    public Node[] split() {
        if (head == null) {
            return new Node[]{null, null};
        }

        Node slow = head;
        Node fast = head;
        Node prev = null;

        while (fast != null && fast.next != null) {
            fast = fast.next.next;
            prev = slow;
            slow = slow.next;
        }

        Node firstHalf = head;
        Node secondHalf = slow;

        if (prev != null) {
            prev.next = null;
        }

        return new Node[]{firstHalf, secondHalf};
    }

    public static void main(String[] args) {
        Linkedlist_split9 list = new Linkedlist_split9();
        list.addLast(1);
        list.addLast(5);
        list.addLast(20);
        list.addLast(6);
        list.addLast(1);

        System.out.println("Original list:");
        list.printlist(list.head);

        Node[] halves = list.split();

        System.out.println("First half:");
        list.printlist(halves[0]);

        System.out.println("Second half:");
        list.printlist(halves[1]);
    }
}