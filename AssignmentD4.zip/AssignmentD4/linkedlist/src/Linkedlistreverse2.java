 class Linkedlistreverse2 {
        Node head;
        public class Node{
            String data;
            Node next;
            Node (String data){
                this.data=data;
                this.next=null;
            }
        }
        public void addLast(String data){
            Node newNode=new Node(data);
            if(head==null){
                head=newNode;
                return;
            }
            Node currNode=head;
            while(currNode.next!=null){
                currNode=currNode.next;
            }
            currNode.next=newNode;
        }
        public void printlist(){
            Node currNode=head;
            while (currNode!=null){
                System.out.print(currNode.data+"-->");
                currNode=currNode.next;
            }
            System.out.println("null");
        }
        public void removeFirst(){
            if(head==null){
                System.out.println("Empty list Nothing to delete");
                return;
            }
            head=head.next;
        }
        public void reverse(){
            if(head==null || head.next==null){
                return;
            }
            Node prevNode=head;
            Node currNode=head.next;
            while(currNode!=null){
                Node nextNode=currNode.next;
                currNode.next=prevNode;
                //update
                prevNode=currNode;
                currNode=nextNode;
            }
            head.next=null;
            head=prevNode;
        }

        public static void main(String[] args) {
            Linkedlistreverse2  list=new Linkedlistreverse2();
            list.addLast("my");
            list.addLast("name");
            list.addLast("is");
            list.addLast("anjali");
            list.printlist();
            list.reverse();
            list.printlist();

        }

    }


