public class searchstring2 {
    public static void main(String[] args) {
        String arr[]={"anjali","anu","suchi","harpreet"};
        String target="anu";
        boolean found=false;
        for(int i=0;i<arr.length;i++){
            if(arr[i].equals("anu")){
                System.out.println("Index of string "+i);
                found=true;
                break;
            }
        }
        if(!found){
            System.out.println("-1");
        }
    }
}
