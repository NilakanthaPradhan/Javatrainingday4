import java.util.ArrayList;

public class Arraylist_rotate6 {
    public static void main(String[] args) {
        ArrayList<Integer> list=new ArrayList<>();
        ArrayList<Integer> result=new ArrayList<>();
        int index=3;
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        for(int i=index;i<= list.size();i++){
            result.add(i);
        }
        for(int i=1;i<index;i++){
            result.add(i);
        }
        System.out.println(result);

    }
}
