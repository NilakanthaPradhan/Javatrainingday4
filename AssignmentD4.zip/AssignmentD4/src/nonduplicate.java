public class nonduplicate {
    public static void main(String[] args) {
        String name="anjali";
        char ch[]=name.toCharArray();
        char result=' ';
        for(int i=0;i<name.length();i++) {
            boolean duplicate=false;
            for (int j = 0; j < name.length(); j++) {
                if (i !=j && ch[i] == ch[j]) {
                   duplicate=true;
                    break;
                }
            }
            if(!duplicate){
                result=ch[i];
            }
        }
        System.out.println(result);
    }
}
