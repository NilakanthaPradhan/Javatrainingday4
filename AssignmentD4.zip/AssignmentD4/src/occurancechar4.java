import java.util.HashMap;
import java.util.Scanner;

public class occurancechar4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String value=sc.nextLine();

        char ch[]=value.toCharArray();
        HashMap<Character,Integer> map=new HashMap<>();
        for(int i=0;i<ch.length;i++){
            int count=0;
            for(int j=0;j<ch.length;j++){
                if(ch[i]==ch[j]){
                    count++;
                }
                map.put(ch[i],count);
            }

        }
        System.out.println(map);
    }
}
