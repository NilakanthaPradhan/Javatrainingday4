import java.util.HashMap;

public class occurence6 {
    public static void main(String[] args) {
        int arr[] = {12, 3, 2, 1, 6, 12, 1};
        int size = arr.length;
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < size; i++) {
            int count = 0;
            for (int j = 0; j < size; j++) {
                if (arr[i] == arr[j]) {
                    count++;
                }
            }
            map.put(arr[i], count);

        }
        System.out.println(map);
    }
}


