import java.util.ArrayList;

public class Arraylist_palindrome {
    public static void main(String[] args) {
        ArrayList<Character> list=new ArrayList<>();
        list.add('r');
        list.add('a');
        list.add('c');
        list.add('e');
        list.add('c');
        list.add('a');
        list.add('r');
        int left=0;
        int right= list.size()-1;
        while(left<right){
            if(!list.get(left).equals(list.get(right))){
                System.out.println("false");
                return;
            }
            left++;
            right--;

        }
        System.out.println("true");

    }
}
