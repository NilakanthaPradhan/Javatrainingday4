public class Sorting_heap6 {
    public static void maxheapify(int A[],int n,int i){
            int largest=i;
            int l=(2*i);
            int r=(2*i)+1;
            if(l<n && A[l]>A[largest]){
                largest=l;
            }
            if(r<n && A[r]>A[largest]){
                largest=r;

            }
            if(largest!=i){
                int temp=A[i];
                A[i]=A[largest];
                A[largest]=temp;
                maxheapify(A,n,largest);
            }
        }
        public static void heapsort1(int A[],int n){
            int i;
            for(i=n/2-1;i>=0;i--){
                maxheapify(A,n,i);
            }
            for(i=n-1;i>=0;i--)
            {

                int temp=A[0];
                A[0]=A[i];
                A[i]=temp;
                maxheapify(A,i,0);
            }
        }

        public static void main(String args[]){
            int arr[]={5,7,98,23,11};
            int n=arr.length;
            heapsort1(arr,n);
            for(int i=0;i<n;i++){
                System.out.println(arr[i]);
            }
        }
    }


