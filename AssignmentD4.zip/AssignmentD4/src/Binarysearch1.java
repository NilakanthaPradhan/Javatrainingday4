public class Binarysearch1 {
    public static void main(String[] args) {
        int arr[]={5,8,9,10,22};
        int target=10;
        int low=0;
        int high= arr.length-1;
        int mid=0;

        while(low<=high){
            mid=(low+high)/2;
            if(arr[mid]==target){
                System.out.println("element found at index "+mid);
                break;
            }else if(arr[mid]>target){
                high=mid-1;
            }else{
                low=mid+1;
            }
        }if(low>high) {
            System.out.println("-1");
        }
    }
}
