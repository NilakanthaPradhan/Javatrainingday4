import java.util.ArrayList;

public class Arraylist_largestsmallest {
    public static void main(String[] args) {
        ArrayList<Integer> list=new ArrayList<>();
        list.add(3);
        list.add(9);
        list.add(12);
        list.add(1);
        list.add(4);
        int max=Integer.MIN_VALUE;
        int min=Integer.MAX_VALUE;
        for(int i=0;i<list.size();i++){
            if(list.get(i)>max){
                max=list.get(i);
            }
        }
        for(int i=0;i<list.size();i++){
            if(list.get(i)<min){
                min=list.get(i);
            }
        }
        System.out.println(max);
        System.out.println(min);
    }
}
