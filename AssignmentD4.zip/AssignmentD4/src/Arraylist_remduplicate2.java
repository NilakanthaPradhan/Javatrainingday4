import java.util.*;
public class Arraylist_remduplicate2 {
    public static void main(String[] args) {
        ArrayList<Integer> list=new ArrayList<Integer>();
        list.add(1);
        list.add(2);
        list.add(1);
        list.add(3);
        list.add(4);
        list.add(3);
        HashSet<Integer> remduplicate=new HashSet<>();
        for(int i=0;i<list.size();i++){
            Integer num= list.get(i);
            if(!remduplicate.contains(num)){
                remduplicate.add(num);
            }
        }
        System.out.println("After removing duplicate element "+remduplicate);
    }
}
