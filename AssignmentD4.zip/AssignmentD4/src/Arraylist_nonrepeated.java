import java.util.ArrayList;
import java.util.HashMap;

public class Arraylist_nonrepeated {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(1);
        list.add(3);
        list.add(9);
        HashMap<Integer,Integer> count=new HashMap<>();
        for(int num:list){
            count.put(num, count.getOrDefault(num,0)+1);
        }
        for(int num:list){
            if(count.get(num)==1){
                System.out.println(num);
                return;
            }
        }
    }
}
