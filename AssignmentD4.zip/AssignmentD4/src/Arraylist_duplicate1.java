import java.util.ArrayList;
import java.util.HashSet;

public class Arraylist_duplicate1 {
    public static  void main(String[] args) {
        ArrayList<Integer> list=new ArrayList<Integer>();
        list.add(1);
        list.add(2);
        list.add(1);
        list.add(3);
        list.add(4);
        list.add(3);
        HashSet<Integer> seen=new HashSet<>();
        HashSet<Integer> duplicate=new HashSet<>();
        for(int i=0;i<list.size();i++){
            Integer num= list.get(i);
            if(!seen.add(num)){
                duplicate.add(num);
            }
        }
        System.out.println("duplicate element "+duplicate);
    }
}
