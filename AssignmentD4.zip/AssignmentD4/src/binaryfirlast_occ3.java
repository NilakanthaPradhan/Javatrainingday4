public class binaryfirlast_occ3 {
    public static int firstoccurence(int []arr,int target) {
        int low = 0;
        int high = arr.length - 1;
        int result = -1;
        int mid = 0;
        while (low <= high) {
            mid = (low + high) / 2;
            if (arr[mid] == target) {
                result=mid;
                high=mid-1;
            } else if (arr[mid] > target) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        return result;
    }
    public static int lastoccurence(int arr[],int target){
        int low = 0;
        int high = arr.length - 1;
        int result = -1;
        while (low <= high) {
            int mid = low+(high-low)/ 2;
            if (arr[mid] == target) {
                result=mid;
                low=mid+1;
            } else if (arr[mid] > target) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        return result;
    }
    public static void main(String[] args) {
        int arr[]={5,8,9,10,22,22};
        int target=9;
        int firstindex=firstoccurence(arr,target);
        int lastindex=lastoccurence(arr,target);
        System.out.println("First occurence "+firstindex);
        System.out.println("Last occurence "+lastindex);
    }
}
