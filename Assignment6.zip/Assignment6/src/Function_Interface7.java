import java.util.function.Function;

public class Function_Interface7{
    public static void main(String[] args) {
        // Function to calculate the area of a circle given its radius
        Function<Double, Double> calculateArea = radius -> Math.PI * radius * radius;

        // Example radius
        double radius = 5.0;

        // Calculate the area using the Function
        double area = calculateArea.apply(radius);

        // Print the result
        System.out.println("The area of a circle with radius " + radius + " is: " + area);
    }
}