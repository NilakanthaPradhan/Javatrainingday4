@FunctionalInterface
interface sumfunction{
    int sum(int a,int b);
}
public class Functional_Interface1{
    public static void main(String[] args) {
        sumfunction res=(a,b)->a+b;
        int finalres=res.sum(5,3);
        System.out.println(finalres);
    }
}