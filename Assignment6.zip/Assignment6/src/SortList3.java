import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;

class Person {
    private String name;
    private int age;
    private double salary;

    public Person(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + ", salary=" + salary + '}';
    }
}

public class SortList3
{
    public static void main(String[] args) {

        List<Person> people = new ArrayList<>();
        people.add(new Person("Alice", 30, 70000));
        people.add(new Person("Bob", 25, 50000));
        people.add(new Person("Charlie", 35, 80000));
        people.add(new Person("David", 28, 60000));
        people.add(new Person("Eve", 22, 45000));


        people.sort(Comparator.comparingInt(Person::getAge));


        people.forEach(System.out::println);
    }
}