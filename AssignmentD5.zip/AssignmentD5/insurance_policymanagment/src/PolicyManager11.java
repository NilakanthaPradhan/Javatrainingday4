import java.time.LocalDate;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class PolicyManager11{
    private Set<Policy> hashSetPolicies = new HashSet<>();
    private Set<Policy> linkedHashSetPolicies = new LinkedHashSet<>();
    private Set<Policy> treeSetPolicies = new TreeSet<>();

    public void addPolicy(Policy policy) {
        hashSetPolicies.add(policy);
        linkedHashSetPolicies.add(policy);
        treeSetPolicies.add(policy);
    }

    public Set<Policy> getAllUniquePolicies() {
        return new LinkedHashSet<>(linkedHashSetPolicies);
    }

    public Set<Policy> getPoliciesExpiringSoon() {
        Set<Policy> expiringSoon = new LinkedHashSet<>();
        LocalDate today = LocalDate.now();
        LocalDate in30Days = today.plusDays(30);

        for (Policy policy : linkedHashSetPolicies) {
            if (policy.getExpiryDate().isBefore(in30Days) && policy.getExpiryDate().isAfter(today)) {
                expiringSoon.add(policy);
            }
        }
        return expiringSoon;
    }

    public Set<Policy> getPoliciesByCoverage(String coverageType) {
        Set<Policy> policiesByCoverage = new LinkedHashSet<>();
        for (Policy policy : linkedHashSetPolicies) {
            if (policy.getCoverageType().equalsIgnoreCase(coverageType)) {
                policiesByCoverage.add(policy);
            }
        }
        return policiesByCoverage;
    }

    public Set<Policy> findDuplicatePolicies() {
        Set<Policy> duplicates = new LinkedHashSet<>();
        Set<String> policyNumbers = new HashSet<>();
        for (Policy policy : hashSetPolicies) {
            if (!policyNumbers.add(policy.getPolicyNumber())) {
                duplicates.add(policy);
            }
        }
        return duplicates;
    }

    public void comparePerformance(int numberOfPolicies) {
        // Performance comparison for HashSet
        Set<Policy> hashSet = new HashSet<>();
        long startTime = System.nanoTime();
        for (int i = 0; i < numberOfPolicies; i++) {
            Policy policy = new Policy("H" + i, "Name" + i, LocalDate.now().plusDays(i), "Coverage", 100.00);
            hashSet.add(policy);
        }
        long endTime = System.nanoTime();
        System.out.println("HashSet: Time to add " + numberOfPolicies + " policies: " + (endTime - startTime) + " ns");

        startTime = System.nanoTime();
        hashSet.contains(new Policy("H" + (numberOfPolicies / 2), "", LocalDate.now(), "", 0));
        endTime = System.nanoTime();
        System.out.println("HashSet: Time to search for a policy: " + (endTime - startTime) + " ns");

        // Performance comparison for LinkedHashSet
        Set<Policy> linkedHashSet = new LinkedHashSet<>();
        startTime = System.nanoTime();
        for (int i = 0; i < numberOfPolicies; i++) {
            Policy policy = new Policy("L" + i, "Name" + i, LocalDate.now().plusDays(i), "Coverage", 100.00);
            linkedHashSet.add(policy);
        }
        endTime = System.nanoTime();
        System.out.println("LinkedHashSet: Time to add " + numberOfPolicies + " policies: " + (endTime - startTime) + " ns");

        startTime = System.nanoTime();
        linkedHashSet.contains(new Policy("L" + (numberOfPolicies / 2), "", LocalDate.now(), "", 0));
        endTime = System.nanoTime();
        System.out.println("LinkedHashSet: Time to search for a policy: " + (endTime - startTime) + " ns");

        // Performance comparison for TreeSet
        Set<Policy> treeSet = new TreeSet<>();
        startTime = System.nanoTime();
        for (int i = 0; i < numberOfPolicies; i++) {
            Policy policy = new Policy("T" + i, "Name" + i, LocalDate.now().plusDays(i), "Coverage", 100.00);
            treeSet.add(policy);
        }
        endTime = System.nanoTime();
        System.out.println("TreeSet: Time to add " + numberOfPolicies + " policies: " + (endTime - startTime) + " ns");

        startTime = System.nanoTime();
        treeSet.contains(new Policy("T" + (numberOfPolicies / 2), "", LocalDate.now(), "", 0));
        endTime = System.nanoTime();
        System.out.println("TreeSet: Time to search for a policy: " + (endTime - startTime) + " ns");
    }
}