import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ArrayIntersection10{
    public static void main(String[] args) {
        int[] array1 = {1, 2, 2, 1};
        int[] array2 = {2, 2};

        HashMap<Integer, Integer> map = new HashMap<>();
        List<Integer> intersection = new ArrayList<>();

        for (int num : array1) {
            map.put(num, map.getOrDefault(num, 0) + 1);
        }

        for (int num : array2) {
            if (map.containsKey(num) && map.get(num) > 0) {
                intersection.add(num);
                map.put(num, map.get(num) - 1);
            }
        }

        System.out.println("Intersection: " + intersection);
    }
}

