import java.util.*;

public class Policy_management{
    private Map<String, Policy> policyByID;
    private Map<Date, Policy> policyByExpiryDate;
    private LinkedHashMap<String, Policy> policyByInsertionOrder;

    public Policy_management() {
        policyByID = new HashMap<>();
        policyByExpiryDate = new TreeMap<>();
        policyByInsertionOrder = new LinkedHashMap<>();
    }

    public void addPolicy(Policy policy) {
        policyByID.put(policy.getPolicyID(), policy);
        policyByExpiryDate.put(policy.getExpiryDate(), policy);
        policyByInsertionOrder.put(policy.getPolicyID(), policy);
    }

    public Policy getPolicyByID(String policyID) {
        return policyByID.get(policyID);
    }

    public void displayPoliciesByExpiryDate() {
        for (Policy policy : policyByExpiryDate.values()) {
            System.out.println(policy);
        }
    }

    public void displayPoliciesByInsertionOrder() {
        for (Policy policy : policyByInsertionOrder.values()) {
            System.out.println(policy);
        }
    }

    public static void main(String[] args) {
        Policy_management manager = new Policy_management();

        Policy policy1 = new Policy("P001", "Health", 500.0, 10000.0, new GregorianCalendar(2025, Calendar.JANUARY, 1).getTime());
        Policy policy2 = new Policy("P002", "Life", 1500.0, 50000.0, new GregorianCalendar(2023, Calendar.DECEMBER, 31).getTime());
        Policy policy3 = new Policy("P003", "Auto", 300.0, 7000.0, new GregorianCalendar(2024, Calendar.MARCH, 15).getTime());

        manager.addPolicy(policy1);
        manager.addPolicy(policy2);
        manager.addPolicy(policy3);

        System.out.println("Policies by Expiry Date:");
        manager.displayPoliciesByExpiryDate();

        System.out.println("\nPolicies by Insertion Order:");
        manager.displayPoliciesByInsertionOrder();
    }
}
