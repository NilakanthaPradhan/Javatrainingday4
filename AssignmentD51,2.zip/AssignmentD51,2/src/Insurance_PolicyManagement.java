import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.stream.Collectors;

class Policy{
    private String policyNumber;
    private String policyholder;
    private LocalDate expirationDate;

    public Policy(String policyNumber, String policyholder, LocalDate expirationDate) {
        this.policyNumber = policyNumber;
        this.policyholder = policyholder;
        this.expirationDate = expirationDate;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public String getPolicyholder() {
        return policyholder;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    @Override
    public String toString() {
        return "Policy{" +
                "policyNumber='" + policyNumber + '\'' +
                ", policyholder='" + policyholder + '\'' +
                ", expirationDate=" + expirationDate +
                '}';
    }
}

class PolicyManager {
    private List<Policy> policies = new ArrayList<>();

    public void addPolicy(Policy policy) {
        policies.add(policy);
    }

    public Policy getPolicyByNumber(String policyNumber) {
        for (Policy policy : policies) {
            if (policy.getPolicyNumber().equals(policyNumber)) {
                return policy;
            }
        }
        return null;
    }

    public List<Policy> getPoliciesExpiringSoon(int days) {
        LocalDate now = LocalDate.now();
        return policies.stream()
                .filter(policy -> policy.getExpirationDate().isBefore(now.plusDays(days)))
                .collect(Collectors.toList());
    }

    public List<Policy> getPoliciesByPolicyholder(String policyholder) {
        return policies.stream()
                .filter(policy -> policy.getPolicyholder().equalsIgnoreCase(policyholder))
                .collect(Collectors.toList());
    }

    public void removeExpiredPolicies() {
        LocalDate now = LocalDate.now();
        Iterator<Policy> iterator = policies.iterator();
        while (iterator.hasNext()) {
            Policy policy = iterator.next();
            if (policy.getExpirationDate().isBefore(now)) {
                iterator.remove();
            }
        }
    }
}

public class Insurance_PolicyManagement{
    public static void main(String[] args) {
        PolicyManager policyManager = new PolicyManager();

        policyManager.addPolicy(new Policy("P001", "John Doe", LocalDate.of(2023, 8, 1)));
        policyManager.addPolicy(new Policy("P002", "Jane Smith", LocalDate.of(2024, 8, 30)));
        policyManager.addPolicy(new Policy("P003", "John Doe", LocalDate.of(2023, 7, 15)));

        // Retrieve a policy by its number
        System.out.println("Policy P002: " + policyManager.getPolicyByNumber("P002"));

        // List all policies expiring within the next 30 days
        System.out.println("Policies expiring within 30 days: " + policyManager.getPoliciesExpiringSoon(30));

        // List all policies for a specific policyholder
        System.out.println("Policies for John Doe: " + policyManager.getPoliciesByPolicyholder("John Doe"));

        // Remove policies that are expired
        policyManager.removeExpiredPolicies();
        System.out.println("All policies after removing expired: " + policyManager.getPoliciesExpiringSoon(365));
    }
}
