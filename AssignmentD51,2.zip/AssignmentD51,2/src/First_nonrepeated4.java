import java.util.LinkedHashMap;
import java.util.Scanner;

public class First_nonrepeated4{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = scanner.nextLine();

        LinkedHashMap<Character, Integer> charCountMap = new LinkedHashMap<>();

        for (char c : input.toCharArray()) {
            charCountMap.put(c, charCountMap.getOrDefault(c, 0) + 1);
        }

        for (char c : charCountMap.keySet()) {
            if (charCountMap.get(c) == 1) {
                System.out.println("First non-repeated character: " + c);
                scanner.close();
                return;
            }
        }

        System.out.println("No non-repeated character found.");
        scanner.close();
    }
}